const SUCCESS_MESSAGES : {[key : string ]: string }= {
"login/fulfilled" : "Login Successfully ! ",
"register/fulfilled" : "Register Successfully !",
"updateUser/fulfilled": "User Updated Successfully !"
}
export {
    SUCCESS_MESSAGES
}